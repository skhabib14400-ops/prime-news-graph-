import fs from 'fs';
import path from 'path';
import { DatabaseState, Article, Category, BreakingNewsItem, AdSlot, VideoItem, Author, CommentItem, NewsletterSubscriber, WebsiteSettings, AdminUser } from '../src/types/news.js';
import { authSecurity } from './auth.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

const INITIAL_CATEGORIES: Category[] = [
  { id: 'cat-1', name_bn: 'জাতীয়', name_en: 'National', slug: 'national', color: '#101D35', order_index: 1, description: 'জাতীয় সকল গুরুত্বপূর্ণ সংবাদ' },
  { id: 'cat-2', name_bn: 'আন্তর্জাতিক', name_en: 'International', slug: 'international', color: '#246BFD', order_index: 2, description: 'বিশ্বজুড়ে ঘটে যাওয়া গুরুত্বপূর্ণ ঘটনা' },
  { id: 'cat-3', name_bn: 'রাজনীতি', name_en: 'Politics', slug: 'politics', color: '#DC2626', order_index: 3, description: 'রাজনীতি ও কূটনীতি সংবাদ' },
  { id: 'cat-4', name_bn: 'অর্থনীতি', name_en: 'Business', slug: 'business', color: '#059669', order_index: 4, description: 'বাণিজ্য, পুঁজিবাজার ও অর্থনীতি' },
  { id: 'cat-5', name_bn: 'তথ্যপ্রযুক্তি', name_en: 'Technology', slug: 'technology', color: '#7C3AED', order_index: 5, description: 'এআই, গ্যাজেট ও উদ্ভাবন' },
  { id: 'cat-6', name_bn: 'খেলা', name_en: 'Sports', slug: 'sports', color: '#EA580C', order_index: 6, description: 'ক্রিকেট, ফুটবল ও বৈশ্বিক ক্রীড়াঙ্গন' },
  { id: 'cat-7', name_bn: 'বিনোদন', name_en: 'Entertainment', slug: 'entertainment', color: '#DB2777', order_index: 7, description: 'চলচ্চিত্র, গান ও বিনোদন জগৎ' },
  { id: 'cat-8', name_bn: 'শিক্ষা', name_en: 'Education', slug: 'education', color: '#0891B2', order_index: 8, description: 'উচ্চশিক্ষা ও গবেষণার খবর' },
  { id: 'cat-9', name_bn: 'স্বাস্থ্য', name_en: 'Health', slug: 'health', color: '#16A34A', order_index: 9, description: 'চিকিৎসা বিজ্ঞান ও সুস্থ জীবন' },
  { id: 'cat-10', name_bn: 'জীবনযাপন', name_en: 'Lifestyle', slug: 'lifestyle', color: '#CA8A04', order_index: 10, description: 'ফ্যাশন, ভ্রমণ ও সংস্কৃতি' },
  { id: 'cat-11', name_bn: 'মতামত', name_en: 'Opinion', slug: 'opinion', color: '#4B5563', order_index: 11, description: 'বিশ্লেষণ ও মুক্তকলাম' },
];

const INITIAL_AUTHORS: Author[] = [
  {
    id: 'auth-1',
    name: 'রফিকুল ইসলাম (Rafiqul Islam)',
    bio_bn: 'আন্তর্জাতিক বিষয়ক প্রধান বিশ্লেষক ও জ্যেষ্ঠ সম্পাদক, বৈশ্বিক ভূরাজনীতি ও কূটনীতি বিশেষজ্ঞ।',
    bio_en: 'Senior International Affairs Analyst and Executive Editor specializing in global geopolitics and multilateral accords.',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    email: 'rafiqul@primenewsgraph.com',
    role: 'Executive Editor',
    social_twitter: 'https://twitter.com',
    social_facebook: 'https://facebook.com',
  },
  {
    id: 'auth-2',
    name: 'তানভীর আহমেদ (Tanvir Ahmed)',
    bio_bn: 'জাতীয় রাজনীতি ও অনুসন্ধানমূলক প্রতিবেদনের প্রধান প্রতিবেদক।',
    bio_en: 'Chief Political Correspondent leading investigative reporting and governance accountability.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    email: 'tanvir@primenewsgraph.com',
    role: 'Chief Investigative Correspondent',
    social_twitter: 'https://twitter.com',
  },
  {
    id: 'auth-3',
    name: 'ফারহানা চৌধুরী (Farhana Chowdhury)',
    bio_bn: 'প্রযুক্তি ও উদ্ভাবন বিভাগের সিনিয়র এডিটর, আর্টিফিশিয়াল ইন্টেলিজেন্স গবেষক।',
    bio_en: 'Technology & Frontier Innovation Editor specializing in AI systems, semiconductor manufacturing, and cybersecurity.',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    email: 'farhana@primenewsgraph.com',
    role: 'Technology Editor',
    social_twitter: 'https://twitter.com',
  },
  {
    id: 'auth-4',
    name: 'শামীম রেজা (Shamim Reza)',
    bio_bn: 'ক্রীড়া সম্পাদক ও আন্তর্জাতিক ক্রিকেট বিশ্লেষক।',
    bio_en: 'Sports Editor and International Cricket Analyst covering global tournaments and sports analytics.',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    email: 'shamim@primenewsgraph.com',
    role: 'Sports Editor',
  }
];

const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art-1',
    slug: 'historic-global-diplomatic-summit-un-accord',
    title_bn: 'জাতিসংঘের ঐতিহাসিক শীর্ষ সম্মেলন: বিশ্ব জলবায়ু ও শান্তি চুক্তিতে ১৯৮ দেশের স্বাক্ষর',
    title_en: 'Historic Global Diplomatic Accord: 198 Nations Sign Landmark UN Peace & Climate Treaty',
    summary_bn: 'আন্তর্জাতিক নেতাদের দীর্ঘ আলোচনার পর জেনেভায় গৃহীত হলো যুগান্তকারী ঘোষণা। এতে বৈশ্বিক নিরাপত্তা রক্ষা, সবুজ রূপান্তর এবং প্রযুক্তি বিনিময়ে ঐক্যমত প্রকাশ করেছে বিশ্ব সম্প্রদায়।',
    summary_en: 'Following weeks of intensive multilateral negotiations in Geneva, 198 delegations formalized an unprecedented peace and carbon mitigation framework establishing new international enforcement mechanisms.',
    content_bn: `<p class="lead">জেনেভায় অনুষ্ঠিত বিশেষ জাতিসংঘ সম্মেলনে আজ ইতিহাসের অন্যতম বৃহৎ বৈশ্বিক শান্তি ও পরিবেশগত রূপান্তর চুক্তি স্বাক্ষরিত হয়েছে। ১৯৮টি সার্বভৌম দেশের শীর্ষ কূটনৈতিক প্রতিনিধিরা সম্মিলিত ঘোষণাপত্রে স্বাক্ষর করেন।</p>
<h2>নতুন বৈশ্বিক রূপরেখা ও জলবায়ু সুরক্ষা</h2>
<p>জাতিসংঘ মহাসচিব তার উদ্বোধনী বক্তব্যে বলেন, "বর্তমান বিশ্ব যে বহুমুখী ভূরাজনৈতিক এবং পরিবেশগত চ্যালেঞ্জের মুখোমুখি, তা একক কোনো রাষ্ট্রের পক্ষে মোকাবেলা করা অসম্ভব। আজকের চুক্তি আন্তর্জাতিক আইনের মর্যাদা এবং ভবিষ্যৎ প্রজন্মের নিরাপত্তা নিশ্চিত করবে।"</p>
<blockquote>"আমরা এমন একটি সন্ধিক্ষণে দাঁড়িয়েছি যেখানে বিভেদ ভুলে মানবজাতির অস্তিত্ব রক্ষাই আমাদের প্রধান কর্তব্য।" — জাতিসংঘ মহাসচিব</blockquote>
<p>চুক্তির মূল ধারাসমূহে অনুন্নত ও উন্নয়নশীল দেশগুলোর জন্য ২০০ বিলিয়ন ডলারের জলবায়ু অভিযোজন তহবিল গঠনের অঙ্গীকার করা হয়েছে। এছাড়া আন্তর্জাতিক সীমান্তে শান্তি বজায় রাখা ও পারমাণবিক অস্ত্র নিয়ন্ত্রণ সংক্রান্ত পর্যবেক্ষণ ব্যবস্থা আরও জোরদার করার সিদ্ধান্ত গৃহীত হয়েছে।</p>
<h2>বাণিজ্য ও প্রযুক্তি বিনিময়</h2>
<p>সম্মেলনে বাণিজ্য ক্ষেত্রে সবুজ জ্বালানি প্রযুক্তি করমুক্তভাবে স্থানান্তরের প্রস্তাব বিপুল সংখ্যাগরিষ্ঠতায় পাস হয়। এশীয় ও ইউরোপীয় অর্থনৈতিক জোটের প্রতিনিধিরা একে টেকসই অর্থনীতির পক্ষে এক বিরাট মাইলফলক হিসেবে অভিহিত করেছেন।</p>`,
    content_en: `<p class="lead">In an extraordinary moment of multilateral consensus, representatives from 198 sovereign nations gathered in Geneva today to formally sign the Comprehensive Peace and Climate Security Accord.</p>
<h2>A New Era of Multilateral Governance</h2>
<p>Addressing the plenary assembly, the UN Secretary-General characterized the agreement as a historic turning point: "We stand at an unprecedented juncture where fragmented responses are no longer viable. Today's accord codifies binding obligations to protect human welfare and global stability."</p>
<blockquote>"Our collective security is indivisible from planetary sustainability." — Assembly Resolution 78/B</blockquote>
<p>Key pillars of the accord include a $200 billion climate transition endowment dedicated to vulnerable emerging economies, stringent enforcement metrics for maritime freedom, and transparent technological verification protocols.</p>`,
    category_id: 'cat-2',
    category_slug: 'international',
    category_name_bn: 'আন্তর্জাতিক',
    category_name_en: 'International',
    author_id: 'auth-1',
    author_name: 'রফিকুল ইসলাম (Rafiqul Islam)',
    author_avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    author_role: 'Executive Editor',
    featured_image: '/src/assets/images/news_world_summit_1793801922828.jpg',
    image_caption_bn: 'জেনেভায় আন্তর্জাতিক শান্তি ও জলবায়ু শীর্ষ সম্মেলনে অংশগ্রহণকারী বিশ্ব নেতৃবৃন্দ।',
    image_caption_en: 'World leaders and diplomatic envoys during the plenary session of the Global Accord in Geneva.',
    status: 'published',
    is_featured: true,
    is_editors_choice: true,
    views_count: 14250,
    published_at: new Date(Date.now() - 3600000 * 2).toISOString(),
    updated_at: new Date().toISOString(),
    seo_title: 'জাতিসংঘের ঐতিহাসিক শীর্ষ সম্মেলন: বিশ্ব জলবায়ু ও শান্তি চুক্তি | PRIME NEWS GRAPH',
    seo_description: 'জেনেভায় ১৯৮ দেশের অংশগ্রহণে স্বাক্ষরিত হলো জাতিসংঘের ঐতিহাসিক শান্তি ও পরিবেশগত নিরাপত্তা চুক্তি।',
    reading_time_minutes: 5,
    tags: ['United Nations', 'International', 'Climate Accord', 'Geneva Summit']
  },
  {
    id: 'art-2',
    slug: 'next-generation-quantum-semiconductor-fabrication-breakthrough',
    title_bn: 'সেমিকন্ডাক্টর বিপ্লব: পরবর্তী প্রজন্মের ২-ন্যানোমিটার এআই চিপ উৎপাদনে নতুন দিগন্ত',
    title_en: 'Semiconductor Revolution: Next-Generation 2nm AI Microchip Mass Production Begins',
    summary_bn: 'নতুন আল্ট্রা-ইউভি লিথোগ্রাফি প্রযুক্তির সফল পরীক্ষায় কৃত্রিম বুদ্ধিমত্তা ও কোয়ান্টাম কম্পিউটিং প্রসেসর উৎপাদনে ৪০% কার্যক্ষমতা বৃদ্ধি ও ৬০% কম বিদ্যুৎ খরচের সুসংবাদ মিলেছে।',
    summary_en: 'Cutting-edge extreme ultraviolet (EUV) photolithography enables high-yield 2-nanometer architecture, delivering dramatic performance leaps for artificial intelligence neural engines.',
    content_bn: `<p class="lead">প্রযুক্তি বিশ্বে যুগান্তকারী আলোড়ন সৃষ্টি করে অত্যাধুনিক ২-ন্যানোমিটার সেমিকন্ডাক্টর চিপের বাণিজ্যিক উৎপাদন প্রক্রিয়া শুরু হয়েছে। গবেষক ও প্রকৌশলীদের দাবি, এটি বর্তমান কম্পিউটিং সক্ষমতাকে বহু গুণ ছাড়িয়ে যাবে।</p>
<h2>বিদ্যুৎ সাশ্রয় ও অভাবনীয় গতি</h2>
<p>নতুন স্থাপত্যে ট্রানজিস্টর ঘনত্ব দ্বিগুণ বৃদ্ধি পাওয়ায় ডাটা সেন্টারে কৃত্রিম বুদ্ধিমত্তা মডেল প্রশিক্ষণের বিদ্যুৎ খরচ ৬০ শতাংশ পর্যন্ত হ্রাস পাবে। একই সাথে প্রতিটি প্রসেসরের গতি প্রায় ৪০ শতাংশ বৃদ্ধি পাবে।</p>
<blockquote>"কোয়ান্টাম ও এআই অ্যালগরিদম প্রক্রিয়াকরণে এটি আগামী এক দশকের সবচেয়ে তাৎপর্যপূর্ণ প্রযুক্তিগত অগ্রগতি।" — প্রধান চিপ স্থপতি</blockquote>
<p>বিশ্বজুড়ে স্মার্টফোন, স্বচালিত যানবাহন এবং হাইপারস্কেল ক্লাউড প্ল্যাটফর্মগুলোতে ২০২৭ সালের প্রথম প্রান্তিক থেকেই এই চিপ সরবরাহ শুরু হবে।</p>`,
    content_en: `<p class="lead">Global semiconductor fabrication reached a watershed milestone today as automated cleanrooms officially commenced initial commercial yields of next-generation 2-nanometer neural accelerator nodes.</p>
<h2>Efficiency Re-engineered</h2>
<p>By leveraging extreme ultraviolet lithography and backside power delivery networks, the new silicon architecture slashes inference energy consumption by 60% while unlocking 40% higher clock frequencies.</p>
<p>Major cloud infrastructure providers and autonomous robotics manufacturers are anticipated to integrate the first commercial batches by early next year.</p>`,
    category_id: 'cat-5',
    category_slug: 'technology',
    category_name_bn: 'তথ্যপ্রযুক্তি',
    category_name_en: 'Technology',
    author_id: 'auth-3',
    author_name: 'ফারহানা চৌধুরী (Farhana Chowdhury)',
    author_avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    author_role: 'Technology Editor',
    featured_image: '/src/assets/images/news_tech_ai_chip_1793801922448.jpg',
    image_caption_bn: 'আধুনিক চিপ ফ্যাব্রিকেশন ল্যাবরেটরিতে রোবোটিক সিলিকন ওয়েফার পর্যবেক্ষণরত গবেষক দল।',
    image_caption_en: 'Engineers in sterile semiconductor cleanrooms inspecting silicon wafers under precision optics.',
    status: 'published',
    is_featured: true,
    is_editors_choice: false,
    views_count: 8920,
    published_at: new Date(Date.now() - 3600000 * 5).toISOString(),
    updated_at: new Date().toISOString(),
    seo_title: 'সেমিকন্ডাক্টর বিপ্লব: পরবর্তী প্রজন্মের ২-ন্যানোমিটার এআই চিপ | PRIME NEWS GRAPH',
    seo_description: 'সেমিকন্ডাক্টর উৎপাদন শিল্পে ২-ন্যানোমিটার চিপের বাণিজ্যিক বিপ্লব শুরু। এআই ও কম্পিউটিংয়ে বিশাল অগ্রগতি।',
    reading_time_minutes: 4,
    tags: ['Semiconductor', 'AI', 'Technology', 'Hardware']
  },
  {
    id: 'art-3',
    slug: 'dhaka-metro-rail-network-expansion-phase-two-operational',
    title_bn: 'মেট্রোরেলের নতুন ধাপ চালু: নগর যোগাযোগে নতুন গতি, প্রতিদিন ১০ লাখ যাত্রীর স্বস্তি',
    title_en: 'Metro Rail Phase Two Fully Operational: High-Speed Urban Mobility for 1 Million Daily Riders',
    summary_bn: 'রাজধানীর দীর্ঘ প্রতীক্ষিত বর্ধিত মেট্রোরেল রুট সর্বসাধারণের জন্য খুলে দেওয়া হলো। যানজটমুক্ত দ্রুত যাতায়াতে নগরবাসীর জীবনে এসেছে স্বস্তির নিঃশ্বাস।',
    summary_en: 'Urban commuting achieves a monumental leap forward as the extended rapid transit metro line opens to the public, drastically cutting cross-city travel times and road congestion.',
    content_bn: `<p class="lead">রাজধানীর যানজট নিরসনে নতুন মাইলফলক রচিত হলো আজ। মেট্রোরেল নেটওয়ার্কের বর্ধিত অংশ আনুষ্ঠানিক উদ্বোধনের পর সর্বসাধারণের জন্য উন্মুক্ত করা হয়েছে।</p>
<h2>দ্রুত যাতায়াত ও আধুনিক সুবিধা</h2>
<p>প্রথম দিন থেকেই স্টেশনগুলোতে যাত্রীদের বিপুল উৎসাহ দেখা গেছে। স্বয়ংক্রিয় টিকেটিং, আধুনিক নিরাপত্তা ব্যবস্থা ও শীতাতপ নিয়ন্ত্রিত কোচের কারণে ঘণ্টার পর ঘণ্টার যানজট এখন কয়েক মিনিটের আরামদায়ক ভ্রমণে পরিণত হয়েছে।</p>
<blockquote>"আগে মতিঝিল পৌঁছাতে যেখানে দুই থেকে তিন ঘণ্টা লাগত, এখন মাত্র ২৫ মিনিটে নিরাপদে পৌঁছানো সম্ভব হচ্ছে।" — এক নিয়মিত যাত্রী</blockquote>
<p>কর্তৃপক্ষ জানিয়েছে, এই রুটে দৈনিক প্রায় ১০ লাখ যাত্রী যাতায়াত করতে পারবেন। এতে যেমন প্রচুর জ্বালানি তেল সাশ্রয় হবে, তেমনই কার্বন নিঃসরণ হ্রাসে বিশাল ভূমিকা রাখবে।</p>`,
    content_en: `<p class="lead">In a transformative moment for metropolitan transit, the newly completed extension of the automated elevated metro rail system welcomed its first waves of daily commuters this morning.</p>
<h2>Slashing Travel Hours into Minutes</h2>
<p>The electric rapid transit infrastructure directly bypasses the city's historically congested thoroughfares, reducing typical two-hour bottlenecks to an effortless 25-minute glide across central commercial arteries.</p>
<p>Transit planners estimate the system will accommodate up to one million daily passengers while significantly shrinking automotive emissions.</p>`,
    category_id: 'cat-1',
    category_slug: 'national',
    category_name_bn: 'জাতীয়',
    category_name_en: 'National',
    author_id: 'auth-2',
    author_name: 'তানভীর আহমেদ (Tanvir Ahmed)',
    author_avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    author_role: 'Chief Political Correspondent',
    featured_image: '/src/assets/images/news_dhaka_metro_1793801923998.jpg',
    image_caption_bn: 'সবুজ নগরীর বুক চিরে ছুটে চলা আধুনিক এলিভেটেড মেট্রোরেল।',
    image_caption_en: 'Modern elevated metro rail gliding seamlessly through the urban skyline at golden hour.',
    status: 'published',
    is_featured: true,
    is_editors_choice: true,
    views_count: 12410,
    published_at: new Date(Date.now() - 3600000 * 8).toISOString(),
    updated_at: new Date().toISOString(),
    seo_title: 'মেট্রোরেলের বর্ধিত অংশ চালু: নগর যোগাযোগে ঐতিহাসিক পরিবর্তন | PRIME NEWS GRAPH',
    seo_description: 'মেট্রোরেলের বর্ধিত অংশ চালু হওয়ায় যানজটমুক্ত দ্রুত যাতায়াত নিশ্চিত হয়েছে রাজধানীতে।',
    reading_time_minutes: 4,
    tags: ['Metro Rail', 'National', 'Infrastructure', 'Urban Development']
  },
  {
    id: 'art-4',
    slug: 'world-cup-thriller-championship-final-victory',
    title_bn: 'রুদ্ধশ্বাস ফাইনাল: শেষ ওভারের রোমাঞ্চে বিশ্ব চ্যাম্পিয়নদের অবিস্মরণীয় জয়',
    title_en: 'World Championship Thriller: Last-Over Climax Seals Historic Title Triumph',
    summary_bn: 'ক্রিকেট ইতিহাসের অন্যতম সেরা এক ফাইনালে শেষ বল পর্যন্ত টানটান উত্তেজনা। দুর্দান্ত বোলিং ও অসাধারণ ফিল্ডিংয়ের ওপর ভর করে ট্রফি ঘরে তুলল চ্যাম্পিয়নরা।',
    summary_en: 'In one of the most electric championship finals in sporting memory, a masterful defensive bowling display under floodlights clinched the world title on the penultimate delivery.',
    content_bn: `<p class="lead">ক্রীড়াপ্রেমীদের হৃদস্পন্দন থামিয়ে দেওয়া এক মহানাটকীয় ফাইনালে বিশ্ব আসরের ট্রফি নিজেদের করে নিয়েছে নতুন চ্যাম্পিয়নরা। কানায় কানায় পূর্ণ স্টেডিয়ামে উল্লাসের জোয়ার বয়ে যায়।</p>
<h2>শেষ বলের নাটকীয়তা</h2>
<p>জয়ের জন্য শেষ ওভারে প্রয়োজন ছিল মাত্র ৮ রান। হাতে ছিল দুই উইকেট। তবে জাদুকরী ইয়র্কার ও বুদ্ধিদীপ্ত ফিল্ডিং সাজিয়ে মাত্র ৪ রান খরচ করে জয় ছিনিয়ে নেয় দল।</p>
<blockquote>"এই মুহূর্তটির জন্যই আমরা প্রতিটি দিন ঘাম ঝরিয়েছি। দলের প্রত্যেকে নিজেদের সর্বোচ্চ নিংড়ে দিয়েছে।" — বিজয়ী অধিনায়ক</blockquote>
<p>ম্যান অব দ্য ম্যাচ নির্বাচিত হয়েছেন দুর্দান্ত শতক ও ক্যাচ নেওয়া অলরাউন্ডার তারকা। দেশজুড়ে ক্রিকেট ভক্তরা বিজয় মিছিলে মুখর হয়ে উঠেছেন।</p>`,
    content_en: `<p class="lead">Under brilliant stadium floodlights before an ecstatic sellout crowd of 80,000 spectators, the cricket championship culminated in an unforgettable defensive stand on the final deliveries.</p>
<h2>Nerves of Steel</h2>
<p>Needing eight runs off the final six balls with two wickets remaining, the bowling attack delivered a masterclass of yorkers and precise fielding discipline to secure the coveted trophy.</p>`,
    category_id: 'cat-6',
    category_slug: 'sports',
    category_name_bn: 'খেলা',
    category_name_en: 'Sports',
    author_id: 'auth-4',
    author_name: 'শামীম রেজা (Shamim Reza)',
    author_avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    author_role: 'Sports Editor',
    featured_image: '/src/assets/images/news_cricket_stadium_1793801922344.jpg',
    image_caption_bn: 'ফ্লাডলাইটের আলোয় বিশ্ব আসরের শ্বাসরুদ্ধকর ফাইনাল মুহূর্ত।',
    image_caption_en: 'Athletic power hitting and packed grandstands during the championship title match.',
    status: 'published',
    is_featured: true,
    is_editors_choice: false,
    views_count: 19530,
    published_at: new Date(Date.now() - 3600000 * 12).toISOString(),
    updated_at: new Date().toISOString(),
    seo_title: 'রুদ্ধশ্বাস ফাইনাল: বিশ্ব চ্যাম্পিয়নদের অবিস্মরণীয় জয় | PRIME NEWS GRAPH',
    seo_description: 'ক্রিকেট বিশ্বকাপের রোমাঞ্চকর ফাইনালে শেষ ওভারের নাটকীয়তায় অবিস্মরণীয় ট্রফি জয়।',
    reading_time_minutes: 4,
    tags: ['Cricket', 'World Cup', 'Sports', 'Championship']
  },
  {
    id: 'art-5',
    slug: 'global-economy-inflation-cools-asian-markets-surge',
    title_bn: 'বৈশ্বিক অর্থনীতি: মুদ্রাস্ফীতি নিয়ন্ত্রণে স্বস্তি, এশিয়ার শেয়ারবাজারে রেকর্ড উত্থান',
    title_en: 'Global Economy: Inflation Pressures Subside as Asian Financial Markets Rally',
    summary_bn: 'কেন্দ্রীয় ব্যাংকগুলোর নীতি সুদহার পুনর্নির্ধারণের পর বিশ্ববাজারে স্থিতিশীলতা ফিরেছে। রফতানি আয় বৃদ্ধি ও রেমিট্যান্স প্রবাহে নতুন আশার আলো।',
    summary_en: 'Benchmark indices surged across regional financial exchanges following positive consumer index prints and resilient industrial manufacturing data.',
    content_bn: `<p class="lead">আন্তর্জাতিক মুদ্রা তহবিলের নতুন পূর্বাভাস এবং সরবরাহ শৃঙ্খল স্বাভাবিক হওয়ার খবরে বিশ্ব অর্থনীতিতে ইতিবাচক ধারা তৈরি হয়েছে। মুদ্রাস্ফীতির পারদ নিম্নমুখী হওয়ায় সাধারণ মানুষের জীবনে কিছুটা স্বস্তি ফিরেছে।</p>
<h2>বাণিজ্য ও বিনিয়োগ বৃদ্ধি</h2>
<p>আন্তর্জাতিক বাণিজ্যে পণ্য পরিবহন ব্যয় উল্লেখযোগ্য হারে কমেছে। ফলে তৈরি পোশাক, তথ্যপ্রযুক্তি সেবা এবং প্রক্রিয়াজাত খাদ্য রফতানিতে নতুন গতি সঞ্চারিত হয়েছে। বিশেষজ্ঞদের মতে, আগামী প্রান্তিকে প্রবৃদ্ধির হার আরও উন্নত হবে।</p>`,
    content_en: `<p class="lead">Positive macroeconomic indicators and stabilizing supply chain freight rates catalyzed broad gains across regional and international stock exchanges today.</p>
<h2>Export Momentum Rebounds</h2>
<p>With consumer price index prints declining in major consumer economies, central banks are signaling an accommodating monetary stance, accelerating private capital commitments.</p>`,
    category_id: 'cat-4',
    category_slug: 'business',
    category_name_bn: 'অর্থনীতি',
    category_name_en: 'Business',
    author_id: 'auth-1',
    author_name: 'রফিকুল ইসলাম (Rafiqul Islam)',
    author_avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    author_role: 'Executive Editor',
    featured_image: '/src/assets/images/news_world_summit_1793801922828.jpg',
    image_caption_bn: 'বিশ্ব অর্থনৈতিক সমীক্ষা ও বাণিজ্য সম্মেলন।',
    image_caption_en: 'Economic delegates reviewing international financial outlook figures.',
    status: 'published',
    is_featured: false,
    is_editors_choice: true,
    views_count: 7340,
    published_at: new Date(Date.now() - 3600000 * 16).toISOString(),
    updated_at: new Date().toISOString(),
    seo_title: 'বৈশ্বিক অর্থনীতি ও মুদ্রাস্ফীতি নিয়ন্ত্রণে স্বস্তি | PRIME NEWS GRAPH',
    seo_description: 'বিশ্ববাজারে মুদ্রাস্ফীতি নিয়ন্ত্রণে আসায় শেয়ারবাজারে চাঙ্গাভাব এবং বাণিজ্যে ইতিবাচক সম্ভাবনা।',
    reading_time_minutes: 3,
    tags: ['Economy', 'Markets', 'Business', 'Trade']
  },
  {
    id: 'art-6',
    slug: 'higher-education-ai-research-centers-established',
    title_bn: 'উচ্চশিক্ষা: পাবলিক বিশ্ববিদ্যালয়ে আধুনিক কৃত্রিম বুদ্ধিমত্তা ও রোবোটিক্স ল্যাব স্থাপন',
    title_en: 'Higher Education: State-of-the-Art AI & Robotics Laboratories Launched in Universities',
    summary_bn: 'চতুর্থ শিল্প বিপ্লবের চ্যালেঞ্জ মোকাবিলায় শিক্ষার্থীদের জন্য আন্তর্জাতিক মানের গবেষণা ও ল্যাবরেটরি সুবিধা নিশ্চিত করা হচ্ছে।',
    summary_en: 'Government initiatives and academic partnerships inaugurate specialized supercomputing and autonomous robotics research hubs for graduate scholars.',
    content_bn: `<p class="lead">দেশের শীর্ষস্থানীয় বিশ্ববিদ্যালয়গুলোতে অত্যাধুনিক কৃত্রিম বুদ্ধিমত্তা ও ডেটা সায়েন্স গবেষণাগার আনুষ্ঠানিকভাবে কার্যক্রম শুরু করেছে। এতে শিক্ষক ও শিক্ষার্থীরা আন্তর্জাতিক মানের গবেষণার সুযোগ পাবেন।</p>
<h2>নতুন প্রজন্মের স্কিল ডেভেলপমেন্ট</h2>
<p>নতুন এই ল্যাবগুলোতে সুপারকম্পিউটিং ক্লাস্টার ও রোবোটিক টেস্টিং গ্রাউন্ড রয়েছে। বিশ্ববিদ্যালয়ের উপাচার্য বলেন, "আমাদের তরুণ প্রজন্মকে বিশ্বমঞ্চে নেতৃত্ব দিতে প্রযুক্তিগত দক্ষতায় স্বয়ংসম্পূর্ণ হতে হবে।"</p>`,
    content_en: `<p class="lead">Leading national universities inaugurated high-performance supercomputing research facilities this week to equip doctoral and engineering students with cutting-edge artificial intelligence toolsets.</p>`,
    category_id: 'cat-8',
    category_slug: 'education',
    category_name_bn: 'শিক্ষা',
    category_name_en: 'Education',
    author_id: 'auth-3',
    author_name: 'ফারহানা চৌধুরী (Farhana Chowdhury)',
    author_avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    author_role: 'Technology Editor',
    featured_image: '/src/assets/images/news_tech_ai_chip_1793801922448.jpg',
    image_caption_bn: 'উচ্চশিক্ষা গবেষণাগারে আধুনিক সুপারকম্পিউটিং সিস্টেম।',
    image_caption_en: 'Graduate engineering researchers utilizing advanced laboratory systems.',
    status: 'published',
    is_featured: false,
    is_editors_choice: false,
    views_count: 5210,
    published_at: new Date(Date.now() - 3600000 * 20).toISOString(),
    updated_at: new Date().toISOString(),
    seo_title: 'উচ্চশিক্ষা ও এআই রোবোটিক্স ল্যাব | PRIME NEWS GRAPH',
    seo_description: 'পাবলিক বিশ্ববিদ্যালয়ে আন্তর্জাতিক মানের কৃত্রিম বুদ্ধিমত্তা ল্যাবরেটরি উদ্বোধন।',
    reading_time_minutes: 3,
    tags: ['Education', 'AI Lab', 'Universities', 'Research']
  }
];

const INITIAL_BREAKING_NEWS: BreakingNewsItem[] = [
  {
    id: 'bn-1',
    title_bn: 'ব্রেকিং: জেনেভায় বিশ্ব বাণিজ্য আলোচনায় নতুন কর সহায়তা চুক্তি চূড়ান্ত',
    title_en: 'Breaking: Global Trade Pact Finalized at Geneva Summit with Comprehensive Tariff Relief Provisions',
    target_url: '/news/historic-global-diplomatic-summit-un-accord',
    priority: 1,
    is_active: true,
    label_bn: 'তাজা খবর',
    label_en: 'BREAKING NEWS',
    scroll_speed: 35,
    created_at: new Date().toISOString(),
  },
  {
    id: 'bn-2',
    title_bn: 'মেট্রোরেলের বর্ধিত অংশ সফল উদ্বোধনের পর যাত্রী চলাচল শুরু, নগরজুড়ে উৎসবের আমেজ',
    title_en: 'Metro Rail Phase Two Welcomes First Million Commuters Following Grand Inauguration',
    target_url: '/news/dhaka-metro-rail-network-expansion-phase-two-operational',
    priority: 2,
    is_active: true,
    label_bn: 'জরুরি সংবাদ',
    label_en: 'FLASH',
    scroll_speed: 35,
    created_at: new Date().toISOString(),
  },
  {
    id: 'bn-3',
    title_bn: 'সেমিকন্ডাক্টর বিপ্লব: পরবর্তী প্রজন্মের ২-ন্যানোমিটার চিপ উৎপাদনে বিশাল সফলতা',
    title_en: 'Next-Gen 2nm AI Semiconductor Breakthrough Achieves 40% Speed Gains',
    target_url: '/news/next-generation-quantum-semiconductor-fabrication-breakthrough',
    priority: 3,
    is_active: true,
    label_bn: 'প্রযুক্তি সংবাদ',
    label_en: 'TECH ALERT',
    scroll_speed: 35,
    created_at: new Date().toISOString(),
  },
  {
    id: 'bn-4',
    title_bn: 'রুদ্ধশ্বাস ফাইনালে শেষ ওভারের রোমাঞ্চে বিশ্ব চ্যাম্পিয়নদের জয়',
    title_en: 'Cricket World Cup: Thrilling Last-Over Climax Delivers Grand Championship Victory',
    target_url: '/news/world-cup-thriller-championship-final-victory',
    priority: 4,
    is_active: true,
    label_bn: 'খেলাধুলা',
    label_en: 'SPORTS FLASH',
    scroll_speed: 35,
    created_at: new Date().toISOString(),
  }
];

const INITIAL_ADS: AdSlot[] = [
  {
    id: 'header_banner',
    name: 'Header Top Leaderboard (728x90)',
    format: 'banner',
    ad_code: `<!-- Adsterra 728x90 Header Leaderboard -->
<div style="width:100%;max-width:728px;height:90px;margin:0 auto;background:linear-gradient(135deg,#0F172A,#1E293B);border:1px solid #334155;border-radius:6px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;color:#F8FAFC;box-sizing:border-box;font-family:sans-serif;">
  <div>
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#94A3B8;">Sponsored Advertisement</div>
    <div style="font-size:16px;font-weight:700;color:#38BDF8;">Global Cloud Hosting Solutions</div>
    <div style="font-size:12px;color:#CBD5E1;">Deploy high-speed infrastructure worldwide with 99.99% uptime.</div>
  </div>
  <a href="https://example.com" target="_blank" rel="noopener noreferrer" style="background:#2563EB;color:#FFF;padding:8px 16px;border-radius:4px;font-size:12px;font-weight:600;text-decoration:none;">Explore Now &rarr;</a>
</div>`,
    is_active: true,
    device_target: 'desktop',
    impressions: 24500,
    clicks: 1240,
  },
  {
    id: 'homepage_top',
    name: 'Homepage Top Billboard',
    format: 'banner',
    ad_code: `<!-- Adsterra Homepage Billboard -->
<div style="width:100%;padding:16px 24px;background:#F1F5F9;border:1px dashed #CBD5E1;border-radius:8px;display:flex;align-items:center;justify-content:space-between;">
  <div>
    <span style="font-size:10px;font-weight:700;color:#64748B;letter-spacing:1px;">PROMOTED</span>
    <h4 style="margin:2px 0;font-size:15px;color:#0F172A;">Digital Banking & Seamless International Remittance</h4>
    <p style="margin:0;font-size:12px;color:#475569;">Zero fees on instant overseas transfers this week only.</p>
  </div>
  <a href="https://example.com" target="_blank" style="padding:6px 14px;background:#059669;color:#fff;border-radius:4px;font-size:12px;font-weight:bold;text-decoration:none;">Learn More</a>
</div>`,
    is_active: true,
    device_target: 'all',
    impressions: 18400,
    clicks: 980,
  },
  {
    id: 'between_news',
    name: 'Homepage In-Feed Native Banner',
    format: 'native',
    ad_code: `<!-- Adsterra Native Feed Card -->
<div style="background:#FFFFFF;border:1px solid #E2E8F0;border-radius:8px;padding:16px;display:flex;gap:16px;align-items:center;">
  <div style="width:80px;height:60px;background:#E0F2FE;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#0284C7;font-weight:bold;font-size:12px;">TECH SPONSOR</div>
  <div style="flex:1;">
    <span style="font-size:11px;color:#0284C7;font-weight:bold;">FEATURED PARTNER</span>
    <h4 style="margin:2px 0 4px;font-size:14px;color:#1E293B;">Next-Gen Enterprise Cyber Shield Platform</h4>
    <p style="margin:0;font-size:12px;color:#64748B;">Protect critical databases and web infrastructure from zero-day threats.</p>
  </div>
  <a href="https://example.com" target="_blank" style="padding:6px 12px;border:1px solid #2563EB;color:#2563EB;border-radius:4px;font-size:11px;font-weight:bold;text-decoration:none;">Visit Website</a>
</div>`,
    is_active: true,
    device_target: 'all',
    impressions: 12100,
    clicks: 650,
  },
  {
    id: 'sidebar_banner',
    name: 'Article & Homepage Sidebar (300x250 Medium Rectangle)',
    format: 'banner',
    ad_code: `<!-- Adsterra 300x250 Medium Rectangle -->
<div style="width:300px;min-height:250px;margin:0 auto;background:#1E293B;color:#FFF;border-radius:8px;padding:20px;box-sizing:border-box;display:flex;flex-direction:column;justify-content:space-between;text-align:center;">
  <div style="font-size:10px;color:#94A3B8;letter-spacing:1px;text-transform:uppercase;">Advertisement</div>
  <div>
    <div style="font-size:18px;font-weight:bold;color:#38BDF8;margin-bottom:6px;">Master Data Science & AI</div>
    <div style="font-size:12px;color:#CBD5E1;line-height:1.4;">Enroll in accredited online masterclasses with live mentors.</div>
  </div>
  <a href="https://example.com" target="_blank" style="background:#2563EB;color:#FFF;padding:10px;border-radius:6px;font-weight:bold;font-size:13px;text-decoration:none;margin-top:12px;">Get 50% Off &rarr;</a>
</div>`,
    is_active: true,
    device_target: 'all',
    impressions: 31200,
    clicks: 1890,
  },
  {
    id: 'article_top',
    name: 'Article Top Banner (Above Headline)',
    format: 'banner',
    ad_code: `<!-- Adsterra Article Top Leaderboard -->
<div style="width:100%;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;padding:10px 16px;display:flex;align-items:center;justify-content:space-between;font-size:13px;">
  <span style="color:#64748B;"><strong style="color:#0F172A;">Sponsored:</strong> Compare the best corporate health insurance policies in 2026.</span>
  <a href="https://example.com" target="_blank" style="color:#2563EB;font-weight:bold;text-decoration:none;">Compare Rates &rarr;</a>
</div>`,
    is_active: true,
    device_target: 'all',
    impressions: 15600,
    clicks: 820,
  },
  {
    id: 'article_middle',
    name: 'Article In-Read Content Banner',
    format: 'banner',
    ad_code: `<!-- Adsterra In-Read Banner -->
<div style="margin:24px 0;padding:16px;background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;display:flex;align-items:center;justify-content:space-between;">
  <div>
    <span style="font-size:10px;font-weight:bold;color:#16A34A;">PARTNER SPOTLIGHT</span>
    <h5 style="margin:2px 0;font-size:14px;color:#166534;">Smart Solar Energy Systems for Homes & Businesses</h5>
    <p style="margin:0;font-size:12px;color:#15803D;">Reduce electricity bills by up to 80% with zero initial deposit.</p>
  </div>
  <a href="https://example.com" target="_blank" style="padding:8px 14px;background:#16A34A;color:#fff;border-radius:4px;font-size:12px;font-weight:bold;text-decoration:none;">Get Free Quote</a>
</div>`,
    is_active: true,
    device_target: 'all',
    impressions: 21300,
    clicks: 1120,
  },
  {
    id: 'article_bottom',
    name: 'Article Bottom Banner (Above Comments)',
    format: 'banner',
    ad_code: `<!-- Adsterra Article Footer Banner -->
<div style="width:100%;padding:14px;background:#FEF3C7;border:1px solid #FCD34D;border-radius:6px;display:flex;align-items:center;justify-content:space-between;color:#92400E;">
  <span style="font-size:13px;"><strong>Special Offer:</strong> Subscribe to PRIME NEWS GRAPH Premium for Ad-Free Reading.</span>
  <a href="#newsletter" style="padding:6px 12px;background:#B45309;color:#FFF;border-radius:4px;font-size:11px;font-weight:bold;text-decoration:none;">Learn More</a>
</div>`,
    is_active: true,
    device_target: 'all',
    impressions: 14700,
    clicks: 740,
  },
  {
    id: 'footer_banner',
    name: 'Footer Leaderboard Banner',
    format: 'banner',
    ad_code: `<!-- Adsterra Footer Banner -->
<div style="width:100%;max-width:728px;margin:0 auto;padding:12px;background:#0F172A;border-radius:6px;text-align:center;color:#94A3B8;font-size:12px;">
  <span style="text-transform:uppercase;font-size:10px;display:block;margin-bottom:4px;">Advertisement</span>
  <span style="color:#E2E8F0;">Looking for professional web development and digital marketing? <a href="https://example.com" target="_blank" style="color:#38BDF8;font-weight:bold;">Contact Our Agency &rarr;</a></span>
</div>`,
    is_active: true,
    device_target: 'desktop',
    impressions: 9800,
    clicks: 390,
  },
  {
    id: 'mobile_banner',
    name: 'Mobile Sticky / Floating Bottom Banner (320x50)',
    format: 'banner',
    ad_code: `<!-- Adsterra Mobile Sticky Banner -->
<div style="width:100%;height:50px;background:#1E293B;color:#FFF;display:flex;align-items:center;justify-content:space-between;padding:0 12px;box-sizing:border-box;font-size:11px;">
  <div>
    <span style="color:#38BDF8;font-weight:bold;">Special Deal:</span>
    <span style="color:#CBD5E1;margin-left:4px;">Download Top Finance App Today</span>
  </div>
  <a href="https://example.com" target="_blank" style="background:#2563EB;color:#FFF;padding:4px 10px;border-radius:3px;font-size:10px;font-weight:bold;text-decoration:none;">Install</a>
</div>`,
    is_active: true,
    device_target: 'mobile',
    impressions: 28900,
    clicks: 1640,
  },
  {
    id: 'popunder',
    name: 'Adsterra Popunder Script Controller',
    format: 'popunder',
    ad_code: `<!-- Adsterra Popunder Script (Controlled) -->
<script type="text/javascript">
  /* Adsterra Popunder Script Slot ID 4910291 */
  console.log('[Adsterra] Popunder script initialized on frequency 1/24h');
</script>`,
    is_active: false,
    device_target: 'all',
    impressions: 5400,
    clicks: 310,
  },
  {
    id: 'social_bar',
    name: 'Adsterra Social Bar Web Push / Banner',
    format: 'social_bar',
    ad_code: `<!-- Adsterra Social Bar Script (Controlled) -->
<script type="text/javascript">
  /* Adsterra Social Bar Widget */
  console.log('[Adsterra] Social Bar ready for interactive notifications');
</script>`,
    is_active: true,
    device_target: 'all',
    impressions: 8900,
    clicks: 520,
  }
];

const INITIAL_VIDEOS: VideoItem[] = [
  {
    id: 'vid-1',
    title_bn: 'বিশেষ প্রতিবেদন: বদলে যাওয়া মেগাসিটি ও আধুনিক যোগাযোগ ব্যবস্থার নতুন রূপরেখা',
    title_en: 'Special Documentary: Transforming Megacities and the Future of Urban Transit',
    youtube_id: 'LXb3EKWsInQ',
    category: 'national',
    is_featured: true,
    published_at: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'vid-2',
    title_bn: 'আন্তর্জাতিক বিশ্লেষণ: জেনেভা শান্তি চুক্তি ও বৈশ্বিক ভূরাজনীতির সমীকরণ',
    title_en: 'Global Analysis: Inside the Historic Geneva Accord and Geopolitical Balance',
    youtube_id: 'kJQP7kiw5Fk',
    category: 'international',
    is_featured: true,
    published_at: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: 'vid-3',
    title_bn: 'তথ্যপ্রযুক্তি: পরবর্তী প্রজন্মের কোয়ান্টাম চিপ যেভাবে পাল্টে দেবে আমাদের জীবন',
    title_en: 'Technology Insight: How Quantum and AI Silicon Nodes Will Redefine Daily Life',
    youtube_id: 'fJ9rUzIMcZQ',
    category: 'technology',
    is_featured: false,
    published_at: new Date(Date.now() - 86400000 * 3).toISOString(),
  }
];

const INITIAL_COMMENTS: CommentItem[] = [
  {
    id: 'comm-1',
    article_id: 'art-1',
    article_title: 'জাতিসংঘের ঐতিহাসিক শীর্ষ সম্মেলন: বিশ্ব জলবায়ু ও শান্তি চুক্তিতে ১৯৮ দেশের স্বাক্ষর',
    author_name: 'ড. মাহমুদুর রহমান (Dr. Mahmudur Rahman)',
    author_email: 'mahmud@example.com',
    content: 'এই চুক্তির প্রতিটি ধারা যদি সঠিকভাবে বাস্তবায়িত হয়, তবে তৃতীয় বিশ্বের উপকূলীয় দেশগুলো সবচেয়ে বেশি উপকৃত হবে। নিরপেক্ষ এবং গঠনমূলক সংবাদ পরিবেশনের জন্য প্রাইম নিউজ গ্রাফকে ধন্যবাদ।',
    status: 'approved',
    created_at: new Date(Date.now() - 3600000 * 3).toISOString(),
  },
  {
    id: 'comm-2',
    article_id: 'art-3',
    article_title: 'মেট্রোরেলের নতুন ধাপ চালু: নগর যোগাযোগে নতুন গতি, প্রতিদিন ১০ লাখ যাত্রীর স্বস্তি',
    author_name: 'সাঈদ হাসান (Sayeed Hasan)',
    author_email: 'sayeed@example.com',
    content: 'আজ সকালে প্রথম ভ্রমণ করলাম। অত্যন্ত সুশৃঙ্খল ও পরিষ্কার পরিবেশ। আমাদের দৈনন্দিন কর্মঘণ্টা বেঁচে যাবে এতে।',
    status: 'approved',
    created_at: new Date(Date.now() - 3600000 * 4).toISOString(),
  },
  {
    id: 'comm-3',
    article_id: 'art-4',
    article_title: 'রুদ্ধশ্বাস ফাইনাল: শেষ ওভারের রোমাঞ্চে বিশ্ব চ্যাম্পিয়নদের অবিস্মরণীয় জয়',
    author_name: 'অনিক চৌধুরী (Anik Chowdhury)',
    author_email: 'anik@example.com',
    content: 'অবিশ্বাস্য ম্যাচ! শেষ ওভারের প্রতিটি বল ছিল শ্বাসরুদ্ধকর। অসাধারণ কভারেজ।',
    status: 'approved',
    created_at: new Date(Date.now() - 3600000 * 6).toISOString(),
  }
];

const INITIAL_SUBSCRIBERS: NewsletterSubscriber[] = [
  { id: 'sub-1', email: 'editor.choice@primenewsgraph.com', created_at: new Date(Date.now() - 86400000 * 10).toISOString(), status: 'active' },
  { id: 'sub-2', email: 'reader.global@gmail.com', created_at: new Date(Date.now() - 86400000 * 7).toISOString(), status: 'active' },
  { id: 'sub-3', email: 'investor.news@outlook.com', created_at: new Date(Date.now() - 86400000 * 4).toISOString(), status: 'active' },
  { id: 'sub-4', email: 'tech.digest@yahoo.com', created_at: new Date(Date.now() - 86400000 * 2).toISOString(), status: 'active' },
];

const INITIAL_SETTINGS: WebsiteSettings = {
  site_name: 'PRIME NEWS GRAPH',
  site_tagline_bn: 'সত্য, বস্তুনিষ্ঠতা এবং বৈশ্বিক সাংবাদিকতার নির্ভরযোগ্য প্রতীক',
  site_tagline_en: 'Truth, Objectivity and the Benchmark of Global Digital Journalism',
  logo_text: 'PRIME NEWS GRAPH',
  default_language: 'bn',
  contact_email: 'contact@primenewsgraph.com',
  contact_phone: '+880 1800-NEWSGRAPH',
  contact_address: 'International News Complex, Level 14, Motijheel C/A, Dhaka 1000 & 75 Rockefeller Plaza, New York, NY 10019',
  copyright_text: '© 2026 PRIME NEWS GRAPH. All rights reserved. Global Editorial & Investigative Network.',
  facebook_url: 'https://facebook.com/primenewsgraph',
  twitter_url: 'https://x.com/primenewsgraph',
  youtube_url: 'https://youtube.com/primenewsgraph',
  instagram_url: 'https://instagram.com/primenewsgraph',
  whatsapp_number: '+8801800639747',
  telegram_url: 'https://t.me/primenewsgraph',
  homepage_sections: {
    hero: true,
    breaking: true,
    latest: true,
    popular: true,
    categories: true,
    editors_choice: true,
    videos: true,
    newsletter: true,
  }
};

const initialAdminHash = authSecurity.hashPassword('mdalamin11gtN');

const INITIAL_ADMINS: AdminUser[] = [
  {
    id: 'adm-owner-1',
    username: 'alamin11gtN',
    email: 'alamin11gtN@primenewsgraph.com',
    password_hash: initialAdminHash.hash,
    salt: initialAdminHash.salt,
    role: 'super_admin',
    two_factor_enabled: true,
    recovery_codes: ['PNG-9821-4192', 'PNG-3019-8472', 'PNG-5819-2741', 'PNG-4918-2048', 'PNG-6729-1092'],
    last_login: new Date().toISOString()
  }
];

class Database {
  private state: DatabaseState;

  constructor() {
    this.state = this.load();
  }

  private load(): DatabaseState {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);

        // Ensure only alamin11gtN is the authorized super admin
        let adminUsers: AdminUser[] = parsed.admin_users || [];
        const alaminRecord = adminUsers.find(a => a.username === 'alamin11gtN');
        if (!alaminRecord || !alaminRecord.password_hash) {
          adminUsers = INITIAL_ADMINS;
        } else {
          // Remove unauthorized demo accounts (admin, editor, etc.)
          adminUsers = adminUsers.filter(a => a.username === 'alamin11gtN');
        }

        const loadedState: DatabaseState = {
          articles: parsed.articles || INITIAL_ARTICLES,
          categories: parsed.categories || INITIAL_CATEGORIES,
          breaking_news: parsed.breaking_news || INITIAL_BREAKING_NEWS,
          ads: parsed.ads || INITIAL_ADS,
          videos: parsed.videos || INITIAL_VIDEOS,
          authors: parsed.authors || INITIAL_AUTHORS,
          comments: parsed.comments || INITIAL_COMMENTS,
          subscribers: parsed.subscribers || INITIAL_SUBSCRIBERS,
          settings: { ...INITIAL_SETTINGS, ...(parsed.settings || {}) },
          admin_users: adminUsers,
        };
        fs.writeFileSync(DB_FILE, JSON.stringify(loadedState, null, 2), 'utf-8');
        return loadedState;
      }
    } catch (e) {
      console.warn('Error reading database file, using initial data:', e);
    }

    const initial: DatabaseState = {
      articles: INITIAL_ARTICLES,
      categories: INITIAL_CATEGORIES,
      breaking_news: INITIAL_BREAKING_NEWS,
      ads: INITIAL_ADS,
      videos: INITIAL_VIDEOS,
      authors: INITIAL_AUTHORS,
      comments: INITIAL_COMMENTS,
      subscribers: INITIAL_SUBSCRIBERS,
      settings: INITIAL_SETTINGS,
      admin_users: INITIAL_ADMINS,
    };
    this.save(initial);
    return initial;
  }

  public save(data?: DatabaseState): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const toSave = data || this.state;
      fs.writeFileSync(DB_FILE, JSON.stringify(toSave, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write database file:', e);
    }
  }

  public getState(): DatabaseState {
    return this.state;
  }

  public replaceState(newState: DatabaseState): void {
    this.state = newState;
    this.save();
  }

  // Articles
  public getArticles(filter?: { category_slug?: string; status?: string; search?: string; featured?: boolean }): Article[] {
    let list = [...this.state.articles];
    if (filter) {
      if (filter.category_slug && filter.category_slug !== 'all') {
        list = list.filter(a => a.category_slug === filter.category_slug);
      }
      if (filter.status && filter.status !== 'all') {
        list = list.filter(a => a.status === filter.status);
      }
      if (filter.featured !== undefined) {
        list = list.filter(a => a.is_featured === filter.featured);
      }
      if (filter.search) {
        const q = filter.search.toLowerCase();
        list = list.filter(a =>
          a.title_bn.toLowerCase().includes(q) ||
          a.title_en.toLowerCase().includes(q) ||
          a.summary_bn.toLowerCase().includes(q) ||
          a.summary_en.toLowerCase().includes(q) ||
          a.author_name.toLowerCase().includes(q) ||
          a.tags.some(t => t.toLowerCase().includes(q))
        );
      }
    }
    // Sort descending by published_at
    return list.sort((a, b) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime());
  }

  public getArticleBySlug(slug: string): Article | undefined {
    return this.state.articles.find(a => a.slug === slug || a.id === slug);
  }

  public incrementArticleViews(id: string): number {
    const art = this.state.articles.find(a => a.id === id || a.slug === id);
    if (art) {
      art.views_count = (art.views_count || 0) + 1;
      this.save();
      return art.views_count;
    }
    return 0;
  }

  public saveArticle(article: Partial<Article> & { title_bn: string; title_en: string }): Article {
    const now = new Date().toISOString();
    const existingIndex = this.state.articles.findIndex(a => a.id === article.id);

    if (existingIndex >= 0) {
      const updated: Article = {
        ...this.state.articles[existingIndex],
        ...article,
        updated_at: now,
      };
      this.state.articles[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const newArticle: Article = {
        id: article.id || `art-${Date.now()}`,
        slug: article.slug || this.generateSlug(article.title_en || article.title_bn),
        title_bn: article.title_bn,
        title_en: article.title_en,
        summary_bn: article.summary_bn || '',
        summary_en: article.summary_en || '',
        content_bn: article.content_bn || '',
        content_en: article.content_en || '',
        category_id: article.category_id || 'cat-1',
        category_slug: article.category_slug || 'national',
        category_name_bn: article.category_name_bn || 'জাতীয়',
        category_name_en: article.category_name_en || 'National',
        author_id: article.author_id || 'auth-1',
        author_name: article.author_name || 'Prime Editorial Team',
        author_avatar: article.author_avatar || '',
        author_role: article.author_role || 'Staff Writer',
        featured_image: article.featured_image || '/src/assets/images/news_world_summit_1793801922828.jpg',
        image_caption_bn: article.image_caption_bn || '',
        image_caption_en: article.image_caption_en || '',
        gallery_images: article.gallery_images || [],
        video_url: article.video_url || '',
        status: article.status || 'published',
        is_featured: article.is_featured || false,
        is_editors_choice: article.is_editors_choice || false,
        views_count: article.views_count || 1,
        published_at: article.published_at || now,
        updated_at: now,
        seo_title: article.seo_title || article.title_bn,
        seo_description: article.seo_description || article.summary_bn,
        reading_time_minutes: article.reading_time_minutes || 4,
        tags: article.tags || ['News'],
      };
      this.state.articles.unshift(newArticle);
      this.save();
      return newArticle;
    }
  }

  public deleteArticle(id: string): boolean {
    const before = this.state.articles.length;
    this.state.articles = this.state.articles.filter(a => a.id !== id && a.slug !== id);
    if (this.state.articles.length !== before) {
      this.save();
      return true;
    }
    return false;
  }

  public generateSlug(text: string): string {
    const slug = text
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .trim()
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');
    return slug || `article-${Date.now()}`;
  }

  // Categories
  public getCategories(): Category[] {
    return [...this.state.categories].sort((a, b) => a.order_index - b.order_index);
  }

  public saveCategory(cat: Partial<Category> & { name_bn: string; name_en: string; slug: string }): Category {
    const existingIndex = this.state.categories.findIndex(c => c.id === cat.id);
    if (existingIndex >= 0) {
      const updated = { ...this.state.categories[existingIndex], ...cat };
      this.state.categories[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const newCat: Category = {
        id: cat.id || `cat-${Date.now()}`,
        name_bn: cat.name_bn,
        name_en: cat.name_en,
        slug: cat.slug,
        color: cat.color || '#246BFD',
        order_index: cat.order_index ?? (this.state.categories.length + 1),
        description: cat.description || '',
      };
      this.state.categories.push(newCat);
      this.save();
      return newCat;
    }
  }

  public deleteCategory(id: string): boolean {
    const before = this.state.categories.length;
    this.state.categories = this.state.categories.filter(c => c.id !== id && c.slug !== id);
    if (this.state.categories.length !== before) {
      this.save();
      return true;
    }
    return false;
  }

  // Breaking News
  public getBreakingNews(activeOnly = true): BreakingNewsItem[] {
    let list = [...this.state.breaking_news];
    if (activeOnly) {
      list = list.filter(b => b.is_active);
    }
    return list.sort((a, b) => a.priority - b.priority);
  }

  public saveBreakingNews(item: Partial<BreakingNewsItem> & { title_bn: string; title_en: string }): BreakingNewsItem {
    const existingIndex = this.state.breaking_news.findIndex(b => b.id === item.id);
    if (existingIndex >= 0) {
      const updated = { ...this.state.breaking_news[existingIndex], ...item };
      this.state.breaking_news[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const newItem: BreakingNewsItem = {
        id: item.id || `bn-${Date.now()}`,
        title_bn: item.title_bn,
        title_en: item.title_en,
        target_url: item.target_url || '/',
        priority: item.priority || 1,
        is_active: item.is_active ?? true,
        label_bn: item.label_bn || 'ব্রেকিং নিউজ',
        label_en: item.label_en || 'BREAKING NEWS',
        scroll_speed: item.scroll_speed || 35,
        created_at: new Date().toISOString(),
      };
      this.state.breaking_news.unshift(newItem);
      this.save();
      return newItem;
    }
  }

  public deleteBreakingNews(id: string): boolean {
    const before = this.state.breaking_news.length;
    this.state.breaking_news = this.state.breaking_news.filter(b => b.id !== id);
    if (this.state.breaking_news.length !== before) {
      this.save();
      return true;
    }
    return false;
  }

  // Advertisements
  public getAds(): AdSlot[] {
    return this.state.ads;
  }

  public getAdById(id: string): AdSlot | undefined {
    return this.state.ads.find(a => a.id === id);
  }

  public saveAd(ad: Partial<AdSlot> & { id: string }): AdSlot {
    const existingIndex = this.state.ads.findIndex(a => a.id === ad.id);
    if (existingIndex >= 0) {
      const updated = { ...this.state.ads[existingIndex], ...ad };
      this.state.ads[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const newAd: AdSlot = {
        id: ad.id,
        name: ad.name || 'Custom Ad Slot',
        format: ad.format || 'banner',
        ad_code: ad.ad_code || '',
        banner_image_url: ad.banner_image_url || '',
        banner_target_link: ad.banner_target_link || '',
        is_active: ad.is_active ?? true,
        device_target: ad.device_target || 'all',
        impressions: 0,
        clicks: 0,
      };
      this.state.ads.push(newAd);
      this.save();
      return newAd;
    }
  }

  public recordAdImpression(id: string): void {
    const ad = this.state.ads.find(a => a.id === id);
    if (ad) {
      ad.impressions = (ad.impressions || 0) + 1;
      this.save();
    }
  }

  public recordAdClick(id: string): void {
    const ad = this.state.ads.find(a => a.id === id);
    if (ad) {
      ad.clicks = (ad.clicks || 0) + 1;
      this.save();
    }
  }

  // Videos
  public getVideos(): VideoItem[] {
    return this.state.videos;
  }

  public saveVideo(video: Partial<VideoItem> & { title_bn: string; youtube_id: string }): VideoItem {
    const existingIndex = this.state.videos.findIndex(v => v.id === video.id);
    if (existingIndex >= 0) {
      const updated = { ...this.state.videos[existingIndex], ...video };
      this.state.videos[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const newVid: VideoItem = {
        id: video.id || `vid-${Date.now()}`,
        title_bn: video.title_bn,
        title_en: video.title_en || video.title_bn,
        youtube_id: video.youtube_id,
        category: video.category || 'national',
        is_featured: video.is_featured || false,
        published_at: new Date().toISOString(),
      };
      this.state.videos.unshift(newVid);
      this.save();
      return newVid;
    }
  }

  public deleteVideo(id: string): boolean {
    const before = this.state.videos.length;
    this.state.videos = this.state.videos.filter(v => v.id !== id);
    if (this.state.videos.length !== before) {
      this.save();
      return true;
    }
    return false;
  }

  // Authors
  public getAuthors(): Author[] {
    return this.state.authors;
  }

  public saveAuthor(author: Partial<Author> & { name: string }): Author {
    const existingIndex = this.state.authors.findIndex(a => a.id === author.id);
    if (existingIndex >= 0) {
      const updated = { ...this.state.authors[existingIndex], ...author };
      this.state.authors[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const newAuth: Author = {
        id: author.id || `auth-${Date.now()}`,
        name: author.name,
        bio_bn: author.bio_bn || '',
        bio_en: author.bio_en || '',
        avatar: author.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        email: author.email || '',
        role: author.role || 'Contributor',
        social_twitter: author.social_twitter,
        social_facebook: author.social_facebook,
      };
      this.state.authors.push(newAuth);
      this.save();
      return newAuth;
    }
  }

  public deleteAuthor(id: string): boolean {
    const before = this.state.authors.length;
    this.state.authors = this.state.authors.filter(a => a.id !== id);
    if (this.state.authors.length !== before) {
      this.save();
      return true;
    }
    return false;
  }

  // Comments
  public getComments(filter?: { article_id?: string; status?: string }): CommentItem[] {
    let list = [...this.state.comments];
    if (filter?.article_id) {
      list = list.filter(c => c.article_id === filter.article_id);
    }
    if (filter?.status && filter.status !== 'all') {
      list = list.filter(c => c.status === filter.status);
    }
    return list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  public addComment(comment: { article_id: string; author_name: string; author_email: string; content: string }): CommentItem {
    const article = this.state.articles.find(a => a.id === comment.article_id || a.slug === comment.article_id);
    const newComm: CommentItem = {
      id: `comm-${Date.now()}`,
      article_id: comment.article_id,
      article_title: article ? article.title_bn : 'Unknown Article',
      author_name: comment.author_name,
      author_email: comment.author_email,
      content: comment.content,
      status: 'approved', // Auto-approved for frictionless demo, but can be moderated in admin
      created_at: new Date().toISOString(),
    };
    this.state.comments.unshift(newComm);
    this.save();
    return newComm;
  }

  public updateCommentStatus(id: string, status: 'approved' | 'pending' | 'spam'): boolean {
    const comm = this.state.comments.find(c => c.id === id);
    if (comm) {
      comm.status = status;
      this.save();
      return true;
    }
    return false;
  }

  public deleteComment(id: string): boolean {
    const before = this.state.comments.length;
    this.state.comments = this.state.comments.filter(c => c.id !== id);
    if (this.state.comments.length !== before) {
      this.save();
      return true;
    }
    return false;
  }

  // Newsletter
  public getSubscribers(): NewsletterSubscriber[] {
    return this.state.subscribers;
  }

  public addSubscriber(email: string): { success: boolean; message: string } {
    const clean = email.trim().toLowerCase();
    const exists = this.state.subscribers.find(s => s.email.toLowerCase() === clean);
    if (exists) {
      return { success: true, message: 'You are already subscribed to PRIME NEWS GRAPH!' };
    }
    const newSub: NewsletterSubscriber = {
      id: `sub-${Date.now()}`,
      email: clean,
      created_at: new Date().toISOString(),
      status: 'active',
    };
    this.state.subscribers.unshift(newSub);
    this.save();
    return { success: true, message: 'Thank you for subscribing to PRIME NEWS GRAPH!' };
  }

  public deleteSubscriber(id: string): boolean {
    const before = this.state.subscribers.length;
    this.state.subscribers = this.state.subscribers.filter(s => s.id !== id && s.email !== id);
    if (this.state.subscribers.length !== before) {
      this.save();
      return true;
    }
    return false;
  }

  // Settings
  public getSettings(): WebsiteSettings {
    return this.state.settings;
  }

  public updateSettings(newSettings: Partial<WebsiteSettings>): WebsiteSettings {
    this.state.settings = { ...this.state.settings, ...newSettings };
    this.save();
    return this.state.settings;
  }

  // Admin Users & Security Management
  public getAdminUsers(): Omit<AdminUser, 'password_hash' | 'salt'>[] {
    return this.state.admin_users.map(u => this.sanitizeAdminUser(u));
  }

  public getAdminByUsername(identifier: string): AdminUser | undefined {
    const clean = identifier.trim().toLowerCase();
    return this.state.admin_users.find(
      u => u.username.toLowerCase() === clean || u.email.toLowerCase() === clean
    );
  }

  public updateAdminPassword(username: string, newHash: string, newSalt: string): boolean {
    const admin = this.getAdminByUsername(username);
    if (admin) {
      admin.password_hash = newHash;
      admin.salt = newSalt;
      this.save();
      return true;
    }
    return false;
  }

  public updateAdmin2FA(username: string, enabled: boolean): boolean {
    const admin = this.getAdminByUsername(username);
    if (admin) {
      admin.two_factor_enabled = enabled;
      this.save();
      return true;
    }
    return false;
  }

  public updateAdminLastLogin(username: string): void {
    const admin = this.getAdminByUsername(username);
    if (admin) {
      admin.last_login = new Date().toISOString();
      this.save();
    }
  }

  public verifyRecoveryCode(username: string, code: string): boolean {
    const admin = this.getAdminByUsername(username);
    if (!admin || !admin.recovery_codes) return false;
    const cleanCode = code.trim().toUpperCase();
    const index = admin.recovery_codes.findIndex(c => c.toUpperCase() === cleanCode);
    if (index !== -1) {
      admin.recovery_codes.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  public regenerateRecoveryCodes(username: string): string[] {
    const admin = this.getAdminByUsername(username);
    if (!admin) return [];
    const newCodes = Array.from({ length: 5 }, () => `PNG-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`);
    admin.recovery_codes = newCodes;
    this.save();
    return newCodes;
  }

  public sanitizeAdminUser(user: AdminUser): Omit<AdminUser, 'password_hash' | 'salt'> {
    const { password_hash, salt, ...safe } = user;
    return safe;
  }
}

export const db = new Database();
